from app.db.supabase import supabase
from datetime import datetime

TOPICS = [
    "basics", "arrays", "strings", "recursion", "sorting",
    "searching", "dynamic_programming", "graphs", "trees"
]

import random

def initialize_user_mastery(user_id: str):
    """Initializes topic mastery for a new user with a 'warm start'."""
    try:
        # Give a realistic starting point (0.2 to 0.4)
        records = [
            {
                "user_id": user_id, 
                "topic": topic, 
                "skill": round(random.uniform(0.2, 0.4), 2)
            } for topic in TOPICS
        ]
        # Use upsert to avoid errors on re-initialization
        data, count = supabase.table('user_topic_mastery').upsert(records, on_conflict='user_id, topic').execute()
        return data
    except Exception as e:
        print(f"Error initializing mastery for user {user_id}: {e}")
        return None

def get_user_mastery(user_id: str):
    """Retrieves a user's full topic mastery profile."""
    try:
        data, count = supabase.table('user_topic_mastery').select('topic, skill').eq('user_id', user_id).execute()
        if data and len(data[1]) > 0:
            return {item['topic']: item['skill'] for item in data[1]}
        # If no records found, initialize them.
        initialize_user_mastery(user_id)
        # And return the default values
        return {topic: 0.5 for topic in TOPICS}
    except Exception as e:
        print(f"Error getting mastery for user {user_id}: {e}")
        return {}

def update_mastery(user_id: str, topic: str, success: float, time_taken: float, attempts: int):
    """Updates a user's mastery for a specific topic after a problem submission."""
    try:
        # 1. Fetch current mastery
        data, count = supabase.table('user_topic_mastery').select('skill, attempt_count').eq('user_id', user_id).eq('topic', topic).execute()
        
        if not data or len(data[1]) == 0:
            initialize_user_mastery(user_id)
            current_mastery = 0.5
            total_attempts = 0
        else:
            current_mastery = data[1][0]['skill']
            total_attempts = data[1][0]['attempt_count']

        # 2. Normalize inputs
        normalized_time = min(time_taken / 300.0, 1.0)
        normalized_attempts = min(attempts / 5.0, 1.0)

        # 3. Compute performance score
        performance_score = (success * 0.6) + ((1 - normalized_time) * 0.2) + ((1 - normalized_attempts) * 0.2)

        # 4. Calculate new mastery
        new_mastery = (0.7 * current_mastery) + (0.3 * performance_score)
        new_mastery = max(0.0, min(1.0, new_mastery)) # Clamp mastery between 0 and 1

        # 5. Update database
        updated_record = {
            "skill": new_mastery,
            "attempt_count": total_attempts + 1,
            "last_updated": datetime.now().isoformat()
        }
        data, count = supabase.table('user_topic_mastery').update(updated_record).eq('user_id', user_id).eq('topic', topic).execute()
        
        return data[1][0] if data and len(data[1]) > 0 else None

    except Exception as e:
        print(f"Error updating mastery for user {user_id}, topic {topic}: {e}")
        return None

def get_weak_topics(user_id: str):
    """Returns topics where user mastery is below 0.4."""
    try:
        data, count = supabase.table('user_topic_mastery').select('topic').eq('user_id', user_id).lt('skill', 0.4).execute()
        return [item['topic'] for item in data[1]] if data else []
    except Exception as e:
        print(f"Error getting weak topics for user {user_id}: {e}")
        return []

def get_strong_topics(user_id: str):
    """Returns topics where user mastery is above 0.75."""
    try:
        data, count = supabase.table('user_topic_mastery').select('topic').eq('user_id', user_id).gt('skill', 0.75).execute()
        return [item['topic'] for item in data[1]] if data else []
    except Exception as e:
        print(f"Error getting strong topics for user {user_id}: {e}")
        return []

def get_user_progress(user_id: str):
    """Combined view of global skill score and topic mastery."""
    try:
        # 1. Get Skill Score from users table
        user_res = supabase.table('users').select('skill_score').eq('id', user_id).single().execute()
        skill_score = user_res.data.get('skill_score', 0.3) if user_res.data else 0.3
        
        # 2. Get Topic Mastery
        mastery = get_user_mastery(user_id)
        
        # 3. Check if new user (no attempts)
        attempts_res = supabase.table('user_attempts').select('id', count='exact').eq('user_id', user_id).execute()
        has_attempts = False
        if isinstance(attempts_res, tuple):
             has_attempts = attempts_res[1] > 0
        else:
             has_attempts = (attempts_res.count or 0) > 0
        
        return {
            "user_id": user_id,
            "skill_score": skill_score,
            "topic_mastery": mastery,
            "is_new_user": not has_attempts
        }
    except Exception as e:
        print(f"Error getting progress for user {user_id}: {e}")
        return {"user_id": user_id, "skill_score": 0.3, "topic_mastery": {}, "is_new_user": True}
