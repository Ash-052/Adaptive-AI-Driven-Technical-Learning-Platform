import json
import logging
from openai import OpenAI
from app.core.config import get_settings

logger = logging.getLogger(__name__)
settings = get_settings()

class AITutorService:
    def __init__(self):
        self.client = OpenAI(api_key=settings.OPENAI_API_KEY)

    def generate_hint(self, problem: dict, user_code: str, topic: str, difficulty: int) -> dict:
        """
        Generates a concise hint for the user based on their current progress.
        """
        prompt = f"""
        Problem: {problem.get('title')}
        Description: {problem.get('description')}
        Topic: {topic}
        Difficulty: {difficulty}
        User's Current Code:
        ```python
        {user_code}
        ```
        
        Provide a helpful, concise hint to guide the user towards the solution.
        SAFETY RULES:
        - NEVER give the full solution or complete code blocks.
        - Point out logical errors or suggest the next step.
        - Focus on the '{topic}' aspect of the problem.
        
        Return JSON format: {{"response": "Your hint here", "type": "hint"}}
        """
        
        return self._call_gpt(prompt)

    def explain_solution(self, problem: dict, solution: str, skill_level: float) -> dict:
        """
        Explains a solution based on the user's skill level.
        """
        complexity = "simple and foundational" if skill_level < 0.4 else "detailed and optimized"
        
        prompt = f"""
        Problem: {problem.get('title')}
        Solution Code:
        ```python
        {solution}
        ```
        User Skill Level: {skill_level} (Scale 0-1)
        
        Explain this solution in a {complexity} way.
        - For beginners, focus on logic flow and basic syntax.
        - For advanced users, focus on time/space complexity and optimization.
        
        Return JSON format: {{"response": "Your explanation here", "type": "explanation"}}
        """
        
        return self._call_gpt(prompt)

    def analyze_code(self, problem: dict, user_code: str) -> dict:
        """
        Analyzes user code for bugs and provides suggestions.
        """
        prompt = f"""
        Problem: {problem.get('title')}
        User Code:
        ```python
        {user_code}
        ```
        
        Analyze the code for logical errors, efficiency, and edge cases.
        - Be concise.
        - Suggest improvements without solving the entire problem.
        
        Return JSON format: {{"response": "Your analysis here", "type": "analysis"}}
        """
        
        return self._call_gpt(prompt)

    def _call_gpt(self, prompt: str) -> dict:
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": "You are a helpful and expert AI Programming Tutor."},
                    {"role": "user", "content": prompt}
                ],
                response_format={"type": "json_object"}
            )
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            logger.error(f"AI Tutor Service Error: {e}")
            return {"response": "Sorry, I am having trouble connecting to my tutor engine.", "type": "error"}

tutor_service = AITutorService()
